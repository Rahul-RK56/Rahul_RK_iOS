//
//  ViewController.swift
//  PostApi
//
//  Created by CIPL0957 on 05/04/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let myUrl = URL(string: "https://www.swiftdeveloperblog.com/http-post-example-script/");
             
             var request = URLRequest(url:myUrl!)
             
             request.httpMethod = "POST"
             
             let postString = "firstName=James&lastName=Bond";
             
             request.httpBody = postString.data(using: String.Encoding.utf8);
             
             let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                 
                 if error != nil
                 {
                     print("error=\(error)")
                     return
                 }
                 print("response = \(response)")
        
                 do {
                     let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary
                     
                     if let parseJSON = json {
                         
                         let firstNameValue = parseJSON["firstName"] as? String
                         print("firstNameValue: \(firstNameValue)")
                         
                         let lastNameValue = parseJSON["lastName"] as? String
                         print("lastNameValue: \(lastNameValue)")
                     }
                 } catch {
                     print(error)
                 }
             }
             task.resume()
    }
}
 
