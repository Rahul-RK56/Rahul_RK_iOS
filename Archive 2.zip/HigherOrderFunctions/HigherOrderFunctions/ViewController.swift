//
//  ViewController.swift
//  HigherOrderFunctions
//
//  Created by CIPL0957 on 12/04/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Higher Order Functions
        
        //Sorted
        
        let numbers: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let ascendingNumbers = numbers.sorted()
        
        print(numbers)
        print(ascendingNumbers)
        
        
        let numbers1: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let descendingNumbers = numbers1.sorted { (a, b) -> Bool in
            return a > b
        }
        
        print(descendingNumbers)
        
        
        let numbers2: [Int] =  [0,1,3,2,4,5,7,6,8,9]
        let _ = numbers2.sorted { (a, b) -> Bool in
            print("a = \(a)")
            print("b = \(b)")
            print(a > b)
            return a > b
        }
        
        let numbers3: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let evenNumbersFirst = numbers3.sorted { (a,b) -> Bool in
            return a % 2 == 0
        }
        
        print(evenNumbersFirst)
        
        
        //Closure Syntax
        
        let numbers4: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let descendingnumbers4 = numbers4.sorted(by: >)
        
        print(descendingnumbers4)
        
        
        //Map
        
        let numbersAsStrings = numbers.map { (a) -> String in
            return String(a)
        }
        
        print(numbersAsStrings)
        let _: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let numbersAsString = numbers.map { String($0) }
        
        print(numbersAsString)
        
        
        //Filter
        
        
        let _: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let numbersLessThanFive = numbers.filter { (a) -> Bool in
            return a < 5
        }
        print(numbersLessThanFive)
        
        let _: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let numberLessThanFive = numbersLessThanFive.filter { $0 < 5 }
        
        print(numberLessThanFive)
        
        
        //Reduce
        
        let _: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let sumOfAllNumbers = numbers.reduce("") { (result, a) -> String in
            return result + String(a)
        }
        print(sumOfAllNumbers)
        
        
        let _: [Int] = [0,1,3,2,4,5,7,6,8,9]
        let sumOfAllNumber = numbers.reduce("") { ($0) + String($1) }
        
        print(sumOfAllNumber)
    }
    


}

