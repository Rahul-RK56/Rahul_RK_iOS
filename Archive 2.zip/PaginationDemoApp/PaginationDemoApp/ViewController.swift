//
//  ViewController.swift
//  PaginationDemoApp
//
//  Created by CIPL0957 on 13/10/22.
//

import UIKit
import ScrollingPageControl

class ViewController: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

