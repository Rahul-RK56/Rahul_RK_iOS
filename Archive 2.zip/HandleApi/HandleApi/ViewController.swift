//
//  ViewController.swift
//  HandleApi
//
//  Created by CIPL0957 on 18/04/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

