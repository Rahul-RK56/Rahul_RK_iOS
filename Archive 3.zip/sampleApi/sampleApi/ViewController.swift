//
//  ViewController.swift
//  sampleApi
//
//  Created by CIPL0957 on 01/04/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
   
       var newsData = [Flight]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    
        
        let api = "https://api.instantwebtools.net/v1/passenger?page=0&size=10"
        
        let url = URL(string: api)!
        
       var urlRequest =  URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            print(data)
            print(response)
            print(error)
            
            let json = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments)
            
            print(json!)

        }
        task.resume()
    }
}
struct api: Decodable{
    var articles = [Flight]()
}

struct Flight: Decodable {
    var name: String?
    var established : Int?
    var country: String?
    var slogan: String?
    var website: URL?
}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return newsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! newsCell
        let news = newsData[indexPath.row]
        cell.updateCell(news: news)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let news = newsData[indexPath.row]
    }
}
class newsCell: UITableViewCell {
   
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var sloganLabel: UILabel!
    
    
    func updateCell(news: Flight) {
        
        self.nameLabel.text = news.name
        self.sloganLabel.text = news.slogan
    }
}
