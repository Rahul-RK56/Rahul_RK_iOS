//
//  ViewController.swift
//  Sample
//
//  Created by CIPL0957 on 14/09/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

