//
//  ViewController.swift
//  ExpandableTableView
//
//  Created by CIPL0957 on 20/04/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblTableView: UITableView!
    
    var imageArr = ["AfghanistanFlag","AmericaFlag","AustraliaFlag","BangladeshFlag","CanadaFlag","ChinaFlag","EnglandFlag","IndiaFlag","NewzealandFlag","PakistanFlag","SouthAfricaFlag","SriLankaFlag","WestIndiesFlag","ZimbabweFlag"]
    var nameArr = ["Afghanistan","America","Australia","Bangladesh","Canada","China","England","India","Newzealand","Pakistan","South Africa","Sri Lanka","West Indies","Zimbabwe"]
    
    var selectedIndex = -1
    var isCollapse = true
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.tblTableView.delegate = self
        self.tblTableView.dataSource = self
        tblTableView.estimatedRowHeight = 240
        tblTableView.rowHeight = UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.selectedIndex == indexPath.row && isCollapse == true {
            return 240
        }else {
            return 70
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell") as! HomeTableViewCell
        cell.lblName.text = nameArr[indexPath.row]
        cell.imgImage.image = UIImage(named: "\(imageArr[indexPath.row])")
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if selectedIndex == indexPath.row {
            if self.isCollapse == false {
                self.isCollapse = true
            }else {
                 self.isCollapse = false
            }
        }else {
            self.isCollapse = true
        }
            self.selectedIndex = indexPath.row
            tableView.reloadRows(at: [indexPath], with: .automatic)
        }
}

