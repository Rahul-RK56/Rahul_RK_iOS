//
//  ViewController.swift
//  Api integration
//
//  Created by CIPL0957 on 31/03/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let url = URL(string: "https://www.google.com")!
        let session = URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            let str = String(data: data!, encoding: .ascii)
            
            print(str)
            
            print("data \(data)")
            print("response \(response)")
            print("error \(error)")
        }
        
        session.resume()
    }


}

