//
//  ViewController.swift
//  Demo API
//
//  Created by CIPL0957 on 31/03/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var jokeView: UITextView!
    @IBOutlet weak var upvote: UIButton!
    @IBOutlet weak var downvote: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func randomJokes(_ sender: Any) {
        
        let endpoint = "https://joke3.p.rapidapi.com/v1/joke"
        let url = URL(string: endpoint)!
        
        var urlRequest = URLRequest(url: url)
        
        urlRequest.httpMethod = "GET"
        
        urlRequest.addValue("joke3.p.rapidapi.com", forHTTPHeaderField: "x-rapidapi-host")
        urlRequest.addValue("8c31004b09msh1d82702cd331940p1fe45cjsnddc0cb8566a7", forHTTPHeaderField: "x-rapidapi-key")
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error ) in
            
            print(data)
            print(response)
            print(error)
           
        }
        
        task.resume()
    }
    
}

