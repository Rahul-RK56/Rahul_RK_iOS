//
//  aViewController.swift
//  Demo API
//
//  Created by CIPL0957 on 31/03/22.
//

import UIKit

class aViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

        let headers = [
            "X-RapidAPI-Host": "joke3.p.rapidapi.com",
            "X-RapidAPI-Key": "8c31004b09msh1d82702cd331940p1fe45cjsnddc0cb8566a7"
        ]

        let request = NSMutableURLRequest(url: NSURL(string: "https://joke3.p.rapidapi.com/v1/joke")! as URL,
                                                cachePolicy: .useProtocolCachePolicy,
                                            timeoutInterval: 10.0)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers

        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
                print(httpResponse)
            }
        })

        dataTask.resume()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
