//
//  SecondViewController.swift
//  CoreDataApp
//
//  Created by CIPL0957 on 13/10/22.
//

import UIKit


protocol MyDataSendingDelegateProtocol {
    func sendDataToFirstViewController(myData: String)
}

class SecondViewController: UIViewController {
    
    var delegate: MyDataSendingDelegateProtocol? = nil

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var passLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.nameLabel.text = "message"

       
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func OkayAction(_ sender: Any) {
        if self.delegate != nil && self.nameLabel.text != nil {
                    let dataToBeSent = self.nameLabel.text
                    self.delegate?.sendDataToFirstViewController(myData: dataToBeSent!)
//                    dismiss(animated: true, completion: nil)
            self.navigationController?.popViewController(animated: true)
                }
    }
    
}
