//
//  ViewController.swift
//  CoreDataApp
//
//  Created by CIPL0957 on 12/10/22.
//
import UIKit
import CoreData

class ViewController: UIViewController, MyDataSendingDelegateProtocol {
    func sendDataToFirstViewController(myData: String) {
        self.userNameLabel.text = myData
    }
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var passwordLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         // Do any additional setup after loading the view, typically from a nib.
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "getDataSegue" {
                let secondVC: SecondViewController = segue.destination as! SecondViewController
                secondVC.delegate = self
            }
        }

    @IBAction func nextAction(_ sender: Any) {
       let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.popViewController(animated: true)
        
    }
    
}

