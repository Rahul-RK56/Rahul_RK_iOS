//
//  ViewController.swift
//  DemoTabBarApp
//
//  Created by CIPL0957 on 07/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

