//
//  ViewController.swift
//  APIData
//
//  Created by CIPL0957 on 01/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
     var newsData = [Article]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any add itional setup after loading the view.
        parsingJson { data in
            self.newsData = data
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    func parsingJson(completion: @escaping ([Article])->()) {
        let urlstring = "https://newsapi.org/v2/everything?q=apple&from=2022-03-31&to=2022-03-31&sortBy=popularity&apiKey=4eaf1dfe860b4441899238d5d5a781a0"
        let url = URL(string: urlstring)
        guard url != nil else {
            print("Error")
            return 
        }
        let session = URLSession.shared
        let dataTask = session.dataTask(with: url!) { data, response, error in
            if error == nil, data != nil {
                let decoder = JSONDecoder()
                do {
                    let ParsingData = try decoder.decode(NewsApi.self, from: data!)
                    completion(ParsingData.articles)
                }catch {
                    print("Parsing Error")
                }
            }
        }
        dataTask.resume()
    }
}
struct NewsApi: Decodable {
    var status: String
    var totalResults: Int
    var articles: [Article]
}
struct Article: Decodable {
    var author: String?
    var title: String?
    var publishedAt: String?
}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = newsData[indexPath.row].author
        return cell
    }
}
