//
//  ViewController.swift
//  VideoSampleApp
//
//  Created by CIPL0957 on 15/09/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func playButton(_ sender: Any) {
        
        let storyBoard = UIStoryboard(name: "Main", bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PlayVideoViewController") as! PlayVideoViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

