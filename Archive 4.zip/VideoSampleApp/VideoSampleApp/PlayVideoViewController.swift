//
//  PlayVideoViewController.swift
//  VideoSampleApp
//
//  Created by CIPL0957 on 15/09/22.
//

import UIKit
import YouTubePlayer
import AVFoundation
import AVKit

class PlayVideoViewController: UIViewController {

    @IBOutlet weak var playVideoView: YouTubePlayerView!
    var player = AVPlayer()
    var avpController = AVPlayerViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let myURL = "https://www.youtube.com/watch?v=aBMGV8blmM4"
        let url = URL(string:myURL)

        player = AVPlayer(url: url!)

        avpController.player = player

        avpController.view.frame.size.height = playVideoView.frame.size.height

        avpController.view.frame.size.width = playVideoView.frame.size.width

        self.playVideoView.addSubview(avpController.view)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
