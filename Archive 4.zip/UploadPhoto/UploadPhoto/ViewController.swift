//
//  ViewController.swift
//  UploadPhoto
//
//  Created by CIPL0957 on 07/09/22.
//

import UIKit
import AWSS3
import AWSCore



class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBAction func openCameraButton(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
            let camImagePicker = UIImagePickerController()
            camImagePicker.delegate = self
            camImagePicker.sourceType = UIImagePickerController.SourceType.camera;
            camImagePicker.allowsEditing = false
            self.present(camImagePicker, animated: true, completion: nil)
        }
    }
     
     
    @IBAction func openPhotoLibrary(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
 
     
     
    
     
    //handles upload
    var uploadCompletionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
     
    var uploadFileURL: NSURL?
     
 
    override func viewDidLoad() {
        super.viewDidLoad()
         
 
 
        //setting progress bar to 0
        self.progressView.progress = 0.0;
        
      
 
         
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
     
     
     
    //begin upload from photo library
 
    private func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
       
        //first run if its coming from photo album
        if(picker.sourceType == UIImagePickerController.SourceType.photoLibrary)
        {
             
        //getting details of image
            let uploadFileURL = info[UIImagePickerController.InfoKey.referenceURL.rawValue] as! NSURL
         
        let imageName = uploadFileURL.lastPathComponent
            let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first! as String
         
       // getting local path
            let localPath = (documentDirectory as NSString).appendingPathComponent(imageName!)
 
         
        //getting actual image
            let image = info[UIImagePickerController.InfoKey.originalImage.rawValue] as! UIImage
            let data = image.pngData()
        data!.writeToFile(localPath, atomically: true, encoding: <#T##String.Encoding#>) 
         
        let imageData = NSData(contentsOfFile: localPath)!
        let photoURL = NSURL(fileURLWithPath: localPath)
        
        // let imageWithData = UIImage(data: imageData)!
         
         
        //defining bucket and upload file name
        let S3BucketName: String = "bucketNAme"
        let S3UploadKeyName: String = "test_libarayUpload.jpg"
         
         
         
 
        let expression = AWSS3TransferUtilityUploadExpression()
        expression.uploadProgress = {(task: AWSS3TransferUtilityTask, bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) in
            dispatch_async(dispatch_get_main_queue(), {
                let progress = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
                self.progressView.progress = progress
                // self.statusLabel.text = "Uploading..."
                NSLog("Progress is: %f",progress)
            })
        }
         
        self.uploadCompletionHandler = { (task, error) -> Void in
            dispatch_async(dispatch_get_main_queue(), {
                if ((error) != nil){
                    NSLog("Failed with error")
                    NSLog("Error: %@",error!);
                    //    self.statusLabel.text = "Failed"
                }
                else if(self.progressView.progress != 1.0) {
                    //    self.statusLabel.text = "Failed"
                    NSLog("Error: Failed - Likely due to invalid region / filename")
                }
                else{
                    //    self.statusLabel.text = "Success"
                    NSLog("Sucess")
                }
            })
        }
         
            let transferUtility = AWSS3TransferUtility.default()
         
            transferUtility.uploadFile(photoURL as URL, bucket: S3BucketName, key: S3UploadKeyName, contentType: "image/jpeg", expression: expression, completionHandler: uploadCompletionHandler).continueWithBlock { (task) -> AnyObject? in
            if let error = task.error {
                NSLog("Error: %@",error.localizedDescription);
                //  self.statusLabel.text = "Failed"
            }
            if let exception = task.exception {
                NSLog("Exception: %@",exception.description);
                //   self.statusLabel.text = "Failed"
            }
            if let _ = task.result {
                // self.statusLabel.text = "Generating Upload File"
                NSLog("Upload Starting!")
                // Do something with uploadTask.
            }
             
            return nil;
        }
         
            //end if photo library upload
            self.dismiss(animated: true, completion: nil);
         
        }
             
             
            //second check if its coming from camera
        else if(picker.sourceType == UIImagePickerController.SourceType.camera)
        {
         
          //  var imageToSave: UIImage = info(UIImagePickerControllerOriginalImage) as UIImage
            var imageToSave: UIImage = info[UIImagePickerControllerOriginalImage.rawValue] as! UIImage
             
            //defining bucket and upload file name
            let S3BucketName: String = "bucketName"
            //setting temp name for upload
            let S3UploadKeyName = "Test2CameraUpload.jpg"
             
            //settings temp location for image
            let imageName = NSURL.fileURL(withPath: NSTemporaryDirectory() + S3UploadKeyName).lastPathComponent
            let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first! as String
             
            // getting local path
            let localPath = (documentDirectory as NSString).stringByAppendingPathComponent(imageName)
             
             
            //getting actual image
            let image = info[UIImagePickerController.InfoKey.originalImage.rawValue] as! UIImage
            let data = image.pngData()
            data!.writeToFile(localPath, atomically: true)
             
            let imageData = NSData(contentsOfFile: localPath)!
            let photoURL = NSURL(fileURLWithPath: localPath)
             
 
             
            let expression = AWSS3TransferUtilityUploadExpression()
            expression.uploadProgress = {(task: AWSS3TransferUtilityTask, bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) in
                dispatch_async(dispatch_get_main_queue(), {
                    let progress = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
                    self.progressView.progress = progress
                    // self.statusLabel.text = "Uploading..."
                    NSLog("Progress is: %f",progress)
                })
            }
             
            self.uploadCompletionHandler = { (task, error) -> Void in
                DispatchQueue.main.async {
                    if ((error) != nil){
                        NSLog("Failed with error")
                        NSLog("Error: %@",error!);
                        //    self.statusLabel.text = "Failed"
                    }
                    else if(self.progressView.progress != 1.0) {
                        //    self.statusLabel.text = "Failed"
                        NSLog("Error: Failed - Likely due to invalid region / filename")
                    }
                    else{
                        //    self.statusLabel.text = "Success"
                        NSLog("Sucess")
                    }
                })
            }
             
            let transferUtility = AWSS3TransferUtility.default()
             
            transferUtility.uploadFile(photoURL, bucket: S3BucketName, key: S3UploadKeyName, contentType: "image/jpeg", expression: expression, completionHandler: uploadCompletionHandler).continueWithBlock { (task) -> AnyObject? in
                if let error = task.error {
                    NSLog("Error: %@",error.localizedDescription);
                    //  self.statusLabel.text = "Failed"
                }
                if let exception = task.exception {
                    NSLog("Exception: %@",exception.description);
                    //   self.statusLabel.text = "Failed"
                }
                if let _ = task.result {
                    // self.statusLabel.text = "Generating Upload File"
                    NSLog("Upload Starting!")
                    // Do something with uploadTask.
                }
                 
                return nil;
            }
             
            //end if photo library upload
            self.dismiss(animated: true, completion: nil);
             
         
 
        }
        
        else{
            NSLog("")
        }
         
         
    }
   
 
}
   
