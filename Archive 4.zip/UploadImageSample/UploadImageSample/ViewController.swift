//
//  ViewController.swift
//  UploadImageSample
//
//  Created by CIPL0957 on 08/09/22.
//

import UIKit
import Photos

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var UploadButton: UIButton!
    @IBOutlet weak var saveImage: UIButton!
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func saveImage(_ sender: Any) {
        
        guard let image = imageView.image  else{return}
        
       
    }
    @IBAction func uploadImage(_ sender: Any) {
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }
    

}

