//
//  ViewController.swift
//  testoneapp
//
//  Created by CIPL0957 on 23/11/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

