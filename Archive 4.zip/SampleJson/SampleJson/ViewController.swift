//
//  ViewController.swift
//  SampleJson
//
//  Created by CIPL0957 on 01/09/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
        if let path = Bundle.main.path(forResource: "BankName", ofType: "json") {
            do {
                  let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                  let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>, let datas = jsonResult["data"] as? [Any] {
                            // do stuff
                    print(jsonResult)
                  }
              } catch {
                   // handle error
              }
        }
    }
    

}
 
