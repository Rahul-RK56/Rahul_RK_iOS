//
//  SampleViewModel.swift
//  SampleJson
//
//  Created by CIPL0957 on 01/09/22.
//

import Foundation
